
const { Configuration, OpenAIApi } = require("openai");
const {WebhookClient} = require('dialogflow-fulfillment');
const express = require('express');
const configuration = new Configuration({
    apiKey: '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',
});
const openai = new OpenAIApi(configuration);
const app = express();
app.use(express.json());
let users = [];
app.post('/webhook', express.json(), (req, res) => {
    const agent = new WebhookClient({ request: req, response: res });
    //console.log('Dialogflow Request headers: ' + JSON.stringify(req.headers));
    //console.log('Dialogflow Request body: ' + JSON.stringify(req.body));
    async function main(agent) {
        let userSays = req.body.queryResult.queryText;
        let user1 = req.body.session;
        let user = user1.substring(user1.lastIndexOf('/') + 1)
        let addToPrompt = '\nHuman: ' + userSays + '\nAI: ';
        let promptToSend = ''
        let hasId = users.some( vendor => vendor['id'] === user )
        if (hasId) {
            users.forEach( vendor => {
                if (vendor['id'] === user) {
                    let c = vendor.prompt
                    if(c.length > 1000){
                        let firstNewLineIndex = c.indexOf("\n");
                        let secondNewLineIndex = c.indexOf("\n", firstNewLineIndex + 1);
                        let thirdNewLineIndex = c.indexOf("\n", secondNewLineIndex + 1);
                        let newString = c.slice(0, firstNewLineIndex) + c.slice(thirdNewLineIndex);
                        console.log(newString);
                        vendor['prompt'] = newString
                        promptToSend = newString
                    }
                    vendor['prompt'] += addToPrompt;
                    promptToSend = vendor['prompt']
                }
            })
        }else {
            users.push({
                id: user,
                prompt: 'The following is a conversation with a Myavana haircare AI assistant. The assistant is helpful, creative, clever, and very friendly.' + addToPrompt
            })
            promptToSend = 'The following is a conversation with a Myavana haircare AI assistant. The assistant is helpful, creative, clever, and very friendly.' + addToPrompt;
        }
        console.log(promptToSend)
        const response = await openai.createCompletion({
        model: "text-davinci-003",
        prompt: promptToSend,
        temperature: 0.3,
        max_tokens: 1200,
        top_p: 1.0,
        frequency_penalty: 0.0,
        presence_penalty: 0.0,
        stop: [" Human:", " AI:"],
        });
        console.log(response.data.choices[0].text);
        agent.add(`${response.data.choices[0].text}`);
        users.forEach( vendor => {
            if (vendor['id'] === user) {
                let c = vendor.prompt
                if(c.length > 1000){
                    let firstNewLineIndex = c.indexOf("\n");
                    let secondNewLineIndex = c.indexOf("\n", firstNewLineIndex + 1);
                    let thirdNewLineIndex = c.indexOf("\n", secondNewLineIndex + 1);
                    let newString = c.slice(0, firstNewLineIndex) + c.slice(thirdNewLineIndex);
                    console.log(newString);
                    vendor['prompt'] = newString += response.data.choices[0].text
                }
                vendor['prompt'] += response.data.choices[0].text
            }
        })
    }
    let intentMap = new Map();
    intentMap.set('Default Fallback Intent', main);
    agent.handleRequest(intentMap);
}
);
app.listen(80);


